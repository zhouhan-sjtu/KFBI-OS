//  Copyright (c) Wenjun Ying, Department of Mathematics and Institute
//  of Natural Sciences, Shanghai Jiao Tong University, Shanghai 200240.

//  This file is free software; as a special exception the author gives
//  unlimited permission to copy and/or distribute it, with or without
//  modifications, as long as this notice is preserved.

//  This file is distributed in the hope that it will be useful, but
//  WITHOUT ANY WARRANTY, to the extent permitted by law; without even 
//  the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR 
//  PURPOSE.

#ifndef __InnerProduct_h_IS_INCLUDED__
#define __InnerProduct_h_IS_INCLUDED__ 

#include <cmath>

//:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
//template <typename T>
//T computeInnerProduct(const T a[], const T b[], int n)
//{
//  T r = 0;
//  for (int i = 0; i < n; i++) {
//    r += a[i] * b[i];
//  }
//  return r; 
//}

#endif
